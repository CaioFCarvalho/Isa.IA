
export default async function handler(req, res) {
  if (req.method === 'POST') {
    const message = req.body?.message?.text || 'Mensagem vazia';

    // Aqui você pode colocar a lógica da ISA, por enquanto é apenas uma resposta de exemplo
    console.log('Mensagem recebida:', message);

    res.status(200).json({ reply: `Recebi sua mensagem: ${message}` });
  } else {
    res.status(405).json({ error: 'Method not allowed' });
  }
}
